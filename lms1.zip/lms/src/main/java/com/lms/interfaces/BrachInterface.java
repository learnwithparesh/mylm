package com.lms.interfaces;

public interface BrachInterface {
	

}

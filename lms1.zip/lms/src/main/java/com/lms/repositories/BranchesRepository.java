package com.lms.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lms.model.Branches;

@Repository
public interface BranchesRepository  extends JpaRepository<Branches, Long>
{
	Optional<Branches> findById(Long id);
}

package com.lms.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.lms.exceptionhandler.ResourceNotFoundException;
import com.lms.model.Syllabus;
import com.lms.model.SyllabusMainFile;
import com.lms.repositories.BoardsRepository;
import com.lms.repositories.BranchesRepository;
import com.lms.repositories.StandardsRepository;
import com.lms.repositories.SubjectsRepository;
import com.lms.repositories.SyllabusRepository;
import com.lms.service.FileStorage;



@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SyllabusController
{
	@Autowired
	SyllabusRepository sylRepository;
	
	@Autowired
	StandardsRepository stdrepo;
	
	@Autowired
	SubjectsRepository subrepo;
	
	@Autowired
	BranchesRepository brnchrepo;
	
	@Autowired
	BoardsRepository boardsrepo;
	
    @GetMapping("/syllabus")
    public List<Syllabus> getAllSyllabuss() {
        return sylRepository.findAll();
    }

    @GetMapping("/syllabus/{id}")
    public ResponseEntity<Syllabus> getSyllabusById(@PathVariable(value = "id") Long syllabusId)
        throws ResourceNotFoundException {
        Syllabus syllabus = sylRepository.findById(syllabusId)
          .orElseThrow(() -> new ResourceNotFoundException("Syllabus not found for this id :: " + syllabusId));
        return ResponseEntity.ok().body(syllabus);
    }
    
    
    
	/*
	 * @PostMapping("/syllabus") public Syllabus createSyllabus(@ModelAttribute
	 * Syllabus syllabus) {
	 * 
	 * System.out.println("g");
	 * System.out.println("syllabus.get"+syllabus.getDescription());
	 * System.out.println("in add data"+syllabus.getMfile()[0].getAbsolutePath());
	 * for(int i=0; i< syllabus.getMfile().length;i++) {
	 * System.out.println("in add data"+syllabus.getMfile()[i].length());
	 * System.out.println("in add data"+syllabus.getMfile()[i].getAbsolutePath());
	 * // System.out.println("in add data"+syllabus.getMainfile()[i].
	 * getMfileUploadFileName());
	 * 
	 * }
	 * 
	 * Syllabus bn = sylRepository.save(syllabus);
	 * 
	 * //System.out.println("in add data" + bn.getId()); return bn;
	 * 
	 * }
	 */
    
    @Value("${serviceURL}")
	private String UPLOADED_FOLDER;
    private String databaseFolder ="/assets/uploadedfiles/";
    
    
    @Autowired
    FileStorage fileStorage;
    
    @PostMapping("/syllabus")
    public Syllabus uploadFileMulti(@RequestParam("description") String description,@RequestParam("boardid") String boardid,@RequestParam("stdid") String stdid,@RequestParam("branchid") String brnchid,@RequestParam("subid") String subid,@RequestParam("imageFile") MultipartFile[] files) throws Exception {
    	  Syllabus rlist = new Syllabus();
          String directoryName;
		   String result = null;
		   Date today = new Date();
        try {
        	
    		System.out.println("dd"+description);
    		System.out.println("std"+stdid);
    		System.out.println("boardid"+boardid);
    		System.out.println("subid"+subid);
          
         Syllabus mys = new Syllabus();
        		 
         mys.setBranches(brnchrepo.findById(Long.parseLong(boardid)).get());
         mys.setStandards(stdrepo.findById(Long.parseLong(stdid)).get());
         mys.setSubjects(subrepo.findById(Long.parseLong(subid)).get());
        // mys.setBoard(boardsrepo.getOne(Long.parseLong(boardid)));
         mys.setDescription(description);
        		 
        		 
        String today1 = today.toString().replaceAll("[\\s+\\-\\+\\.\\^:,]","");
        	  directoryName = UPLOADED_FOLDER.concat(String.valueOf(today1));
        	  databaseFolder = databaseFolder.concat(String.valueOf(today1));

        	    File directory = new File(directoryName);
        	    if (! directory.exists()){
        	        directory.mkdir();
        	    }

 
        	List<String> fileNames = null;  
	    	Set<SyllabusMainFile> smnewlist = new HashSet<SyllabusMainFile>();
        //	SyllabusMainFile smnew = new SyllabusMainFile();
	    		
		        fileNames = Arrays.asList(files)
		                .stream()
		                .map(file -> {
		                	fileStorage.store1(file,directoryName);
		                	System.out.println("ff"+file.getOriginalFilename());
		                	System.out.println("ff"+directoryName);
		                	
		                	SyllabusMainFile smnew = new SyllabusMainFile(directoryName.concat("/").concat(file.getOriginalFilename()));
		                	smnew.setSyllabus(mys);
		                	smnewlist.add(smnew);
		                	
                    	     return file.getOriginalFilename();
		                })
		                .collect(Collectors.toList());
		       mys.setSyllabusMainFile(smnewlist);
		       rlist = sylRepository.save(mys);	
        }
        // Here Catch IOException only.
        // Other Exceptions catch by RestGlobalExceptionHandler class.
        catch (Exception e) {
            e.printStackTrace();
            return rlist;
  //          return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        int v = 0;
 
      return rlist;
     //return new ResponseEntity<String>("Uploaded to: " + result, HttpStatus.OK);
    }

    @PutMapping("/syllabus/{id}")
    public ResponseEntity<Syllabus> updateSyllabus(@PathVariable(value = "id") Long syllabusId,
         @Valid @RequestBody Syllabus syllabusDetails) throws ResourceNotFoundException {
        Syllabus syllabus = sylRepository.findById(syllabusId)
        .orElseThrow(() -> new ResourceNotFoundException("Syllabus not found for this id :: " + syllabusId));

        
        syllabus.setDescription(syllabusDetails.getDescription());
        
        final Syllabus updatedSyllabus = sylRepository.save(syllabus);
        return ResponseEntity.ok(updatedSyllabus);
    }

    @DeleteMapping("/syllabus/{id}")
    public Map<String, Boolean> deleteSyllabus(@PathVariable(value = "id") Long syllabusId)
         throws ResourceNotFoundException {
        Syllabus syllabus = sylRepository.findById(syllabusId)
       .orElseThrow(() -> new ResourceNotFoundException("Syllabus not found for this id :: " + syllabusId));

        sylRepository.delete(syllabus);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
	
	

}

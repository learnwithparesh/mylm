package com.lms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.lms.config.JwtTokenUtil;
import com.lms.exceptionhandler.ResourceNotFoundException;
import com.lms.model.Branches;
import com.lms.model.Branches2;
import com.lms.repositories.BranchesRepository;
import com.lms.service.JwtUserDetailsService;




@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class BatchesController
{
	@Autowired
	BranchesRepository batchesRepository;
	
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private JwtUserDetailsService userDetailsService;

	
    @GetMapping("/branches")
    public List<Branches> getAllBranchess() {
    	System.out.println("in branches");
        return batchesRepository.findAll();
    }

    @GetMapping("/branches/{id}")
    public ResponseEntity<Branches> getBranchesById(@PathVariable(value = "id") Long branchesId)
        throws ResourceNotFoundException {
        Branches branches = batchesRepository.findById(branchesId)
          .orElseThrow(() -> new ResourceNotFoundException("Branches not found for this id :: " + branchesId));
        return ResponseEntity.ok().body(branches);
    }
    
    @PostMapping("/branches")
    public Branches createBranches(@RequestBody Branches branches) {
    //	System.out.println("in add data"+branches.getMfile().length());
    	//System.out.println("in add data"+branches.getMfile().getAbsolutePath());
    	//System.out.println("in add data"+branches.getMfileUploadFileName());
    	Branches bn = batchesRepository.save(branches);
    	System.out.println("in add data" + bn.getId());
    	return bn;
        
    }

    @PutMapping("/branches/{id}")
    public ResponseEntity<Branches> updateBranches(@PathVariable(value = "id") Long branchesId,
         @Valid @RequestBody Branches branchesDetails) throws ResourceNotFoundException {
        Branches branches = batchesRepository.findById(branchesId)
        .orElseThrow(() -> new ResourceNotFoundException("Branches not found for this id :: " + branchesId));

        branches.setBname(branchesDetails.getBname());
        branches.setDescription(branchesDetails.getDescription());
        
        final Branches updatedBranches = batchesRepository.save(branches);
        return ResponseEntity.ok(updatedBranches);
    }

    @DeleteMapping("/branches/{id}")
    public Map<String, Boolean> deleteBranches(@PathVariable(value = "id") Long branchesId)
         throws ResourceNotFoundException {
        Branches branches = batchesRepository.findById(branchesId)
       .orElseThrow(() -> new ResourceNotFoundException("Branches not found for this id :: " + branchesId));

        batchesRepository.delete(branches);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
	
	

}

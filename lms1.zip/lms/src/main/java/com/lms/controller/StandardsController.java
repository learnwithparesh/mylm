package com.lms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lms.exceptionhandler.ResourceNotFoundException;
import com.lms.model.Standards;
import com.lms.repositories.StandardsRepository;




@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class StandardsController
{
	@Autowired
	StandardsRepository stdRepository;
	
	
    @GetMapping("/standards")
    public List<Standards> getAllstandardss() {
        return stdRepository.findAll();
    }

    @GetMapping("/standards/{id}")
    public ResponseEntity<Standards> getstandardsById(@PathVariable(value = "id") Long standardsId)
        throws ResourceNotFoundException {
        Standards standards = stdRepository.findById(standardsId)
          .orElseThrow(() -> new ResourceNotFoundException("standards not found for this id :: " + standardsId));
        return ResponseEntity.ok().body(standards);
    }
    
    @PostMapping("/standards")
    public Standards createstandards(@RequestBody Standards standards) {
    //	System.out.println("in add data"+standards.getMfile().length());
    	//System.out.println("in add data"+standards.getMfile().getAbsolutePath());
    	//System.out.println("in add data"+standards.getMfileUploadFileName());
    	Standards bn = stdRepository.save(standards);
    	System.out.println("in add data" + bn.getId());
    	return bn;
        
    }

    @PutMapping("/standards/{id}")
    public ResponseEntity<Standards> updatestandards(@PathVariable(value = "id") Long standardsId,
         @Valid @RequestBody Standards standardsDetails) throws ResourceNotFoundException {
        Standards standards = stdRepository.findById(standardsId)
        .orElseThrow(() -> new ResourceNotFoundException("standards not found for this id :: " + standardsId));

        standards.setSname(standardsDetails.getSname());
        standards.setDescription(standardsDetails.getDescription());
        
        final Standards updatedstandards = stdRepository.save(standards);
        return ResponseEntity.ok(updatedstandards);
    }

    @DeleteMapping("/standards/{id}")
    public Map<String, Boolean> deletestandards(@PathVariable(value = "id") Long standardsId)
         throws ResourceNotFoundException {
        Standards standards = stdRepository.findById(standardsId)
       .orElseThrow(() -> new ResourceNotFoundException("standards not found for this id :: " + standardsId));

        stdRepository.delete(standards);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
	
	

}

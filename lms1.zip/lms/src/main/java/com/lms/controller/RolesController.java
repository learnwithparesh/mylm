package com.lms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.model.Roles;
import com.lms.repositories.RolesRepository;

@RestController
public class RolesController 
{
	@Autowired
	RolesRepository repo;
	

	@RequestMapping(value = "/getroles")
	public List<Roles> getworkflow() 
	{

		List<Roles> roless = (List<Roles>) repo.findAll();
	
		return roless;
	}


}

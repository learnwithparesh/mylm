package com.lms.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.lms.exceptionhandler.ResourceNotFoundException;
import com.lms.model.Topics;
import com.lms.model.TopicsMainFile;
import com.lms.repositories.BoardsRepository;
import com.lms.repositories.BranchesRepository;
import com.lms.repositories.StandardsRepository;
import com.lms.repositories.SubjectsRepository;
import com.lms.repositories.SyllabusRepository;
import com.lms.repositories.TopicsRepository;
import com.lms.repositories.TopicsRepository;
import com.lms.service.FileStorage;



@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class TopicsController
{
	@Autowired
	SyllabusRepository sylrepo;
	
	@Autowired
	TopicsRepository toprepo;
	
	
    @GetMapping("/topics")
    public List<Topics> getAllTopicss() {
        return toprepo.findAll();
    }

    @GetMapping("/topics/{id}")
    public ResponseEntity<Topics> getTopicsById(@PathVariable(value = "id") Long topicsId)
        throws ResourceNotFoundException {
        Topics topics = toprepo.findById(topicsId)
          .orElseThrow(() -> new ResourceNotFoundException("Topics not found for this id :: " + topicsId));
        return ResponseEntity.ok().body(topics);
    }
    
    @GetMapping("/topicss/{id}")
    public List<Topics> getTopicsById1(@PathVariable(value = "id") Long topicsId)
        throws ResourceNotFoundException {
    	List<Topics> topics =  toprepo.findBySyllabus(sylrepo.findById(topicsId).get());
       return topics;
    }
    
	/*
	 * @PostMapping("/topics") public Topics createTopics(@ModelAttribute
	 * Topics topics) {
	 * 
	 * System.out.println("g");
	 * System.out.println("topics.get"+topics.getDescription());
	 * System.out.println("in add data"+topics.getMfile()[0].getAbsolutePath());
	 * for(int i=0; i< topics.getMfile().length;i++) {
	 * System.out.println("in add data"+topics.getMfile()[i].length());
	 * System.out.println("in add data"+topics.getMfile()[i].getAbsolutePath());
	 * // System.out.println("in add data"+topics.getMainfile()[i].
	 * getMfileUploadFileName());
	 * 
	 * }
	 * 
	 * Topics bn = toprepo.save(topics);
	 * 
	 * //System.out.println("in add data" + bn.getId()); return bn;
	 * 
	 * }
	 */
    
    @Value("${serviceURL}")
	private String UPLOADED_FOLDER;
    private String databaseFolder ="/assets/uploadedfiles/";
    
    
    @Autowired
    FileStorage fileStorage;
    
    @PostMapping("/topics")
    public Topics uploadFileMulti(@RequestParam("tdescription") String tdescription,@RequestParam("tname") String tname,@RequestParam("sid") String sid,@RequestParam("imageFile") MultipartFile[] files) throws Exception {
    	  Topics rlist = new Topics();
          String directoryName;
		   String result = null;
		   Date today = new Date();
        try {
        	
    		System.out.println("dd"+tdescription);
    		System.out.println("sid"+sid);
    		System.out.println("tname"+tname);
    	//	System.out.println("subid"+subid);
          
         Topics mys = new Topics();
        		 
         mys.setDescription(tdescription);
         mys.setTname(tname);
         mys.setSyllabus(sylrepo.findById(Long.parseLong(sid)).get());
         
        // mys.setBoard(boardsrepo.getOne(Long.parseLong(boardid)));
         //mys.setDescription(description);
        		 
        		 
        String today1 = today.toString().replaceAll("[\\s+\\-\\+\\.\\^:,]","");
        	  directoryName = UPLOADED_FOLDER.concat(String.valueOf(today1));
        	  databaseFolder = databaseFolder.concat(String.valueOf(today1));

        	    File directory = new File(directoryName);
        	    if (! directory.exists()){
        	        directory.mkdir();
        	    }

 
        	List<String> fileNames = null;  
	    	Set<TopicsMainFile> smnewlist = new HashSet<TopicsMainFile>();
        //	TopicsMainFile smnew = new TopicsMainFile();
	    		
		        fileNames = Arrays.asList(files)
		                .stream()
		                .map(file -> {
		                	fileStorage.store1(file,directoryName);
		                	System.out.println("ff"+file.getOriginalFilename());
		                	System.out.println("ff"+directoryName);
		                	
		                	TopicsMainFile smnew = new TopicsMainFile(directoryName.concat("/").concat(file.getOriginalFilename()));
		                	smnew.setTopics(mys);
		                	smnewlist.add(smnew);
		                	
                    	     return file.getOriginalFilename();
		                })
		                .collect(Collectors.toList());
		       mys.setTopicsMainFile(smnewlist);
		       rlist = toprepo.save(mys);	
        }
        // Here Catch IOException only.
        // Other Exceptions catch by RestGlobalExceptionHandler class.
        catch (Exception e) {
            e.printStackTrace();
            return rlist;
  //          return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        int v = 0;
 
      return rlist;
     //return new ResponseEntity<String>("Uploaded to: " + result, HttpStatus.OK);
    }

    @PutMapping("/topics/{id}")
    public ResponseEntity<Topics> updateTopics(@PathVariable(value = "id") Long topicsId,
         @Valid @RequestBody Topics topicsDetails) throws ResourceNotFoundException {
        Topics topics = toprepo.findById(topicsId)
        .orElseThrow(() -> new ResourceNotFoundException("Topics not found for this id :: " + topicsId));

        
        topics.setDescription(topicsDetails.getDescription());
        
        final Topics updatedTopics = toprepo.save(topics);
        return ResponseEntity.ok(updatedTopics);
    }

    @DeleteMapping("/topics/{id}")
    public Map<String, Boolean> deleteTopics(@PathVariable(value = "id") Long topicsId)
         throws ResourceNotFoundException {
        Topics topics = toprepo.findById(topicsId)
       .orElseThrow(() -> new ResourceNotFoundException("Topics not found for this id :: " + topicsId));

        toprepo.delete(topics);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
	
	

}

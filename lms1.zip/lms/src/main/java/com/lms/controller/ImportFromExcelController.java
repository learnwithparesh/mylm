package com.lms.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class ImportFromExcelController {
	@PostMapping("/excelfileUpload")
	 public String fileUpload(@RequestParam("uploadfile") MultipartFile file) throws Exception {
	 try {
	 //fileUploadService.store(file);
		 System.out.println("test"+file.getContentType()+" : name :"+file.getName());
	 return "File " + file.getName()+" uploaded successfully!!";
	 } catch (Exception e) {
	 throw new Exception(e.getMessage());
	 }
	 }
}

package com.lms.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="subtopics")
public class Subtopics implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "subtname")
	private String subtname;
	
	@Column(name = "description")
	private String description;
	
	

	
	@OneToMany(mappedBy = "subtopics", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JsonIgnoreProperties("subtopics")
    private Set<SubTopicsMainFile> subTopicsMainFile;
	
	
	
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "topics_id", nullable = false)
	private Topics topics;

	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getSubtname() {
		return subtname;
	}


	public void setSubtname(String subtname) {
		this.subtname = subtname;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Topics getTopics() {
		return topics;
	}


	public void setTopics(Topics topics) {
		this.topics = topics;
	}


	public Set<SubTopicsMainFile> getSubTopicsMainFile() {
		return subTopicsMainFile;
	}


	public void setSubTopicsMainFile(Set<SubTopicsMainFile> subTopicsMainFile) {
		this.subTopicsMainFile = subTopicsMainFile;
	}


	public Subtopics() {
		super();
	}


	public Subtopics(String subtname, String description, Topics topics, Set<SubTopicsMainFile> subTopicsMainFile) {
		super();
		this.subtname = subtname;
		this.description = description;
		this.topics = topics;
		this.subTopicsMainFile = subTopicsMainFile;
	}


	public Subtopics(long id, String subtname, String description, Topics topics,
			Set<SubTopicsMainFile> subTopicsMainFile) {
		super();
		this.id = id;
		this.subtname = subtname;
		this.description = description;
		this.topics = topics;
		this.subTopicsMainFile = subTopicsMainFile;
	}
	
	
}

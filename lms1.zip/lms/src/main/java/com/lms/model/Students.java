package com.lms.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="students")
public class Students implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "fname")
	private String fname;
	
	@Column(name = "mname")
	private String mname;
	
	@Column(name = "lname")
	private String lname;
	
	@Column(name = "qualification")
	private String qualification;
	
	@Temporal(TemporalType.DATE) 
	@JsonFormat( pattern = "dd/MM/yyyy",timezone="IST")
    @Column(name="bdate")
    private Date bdate;
	
	@Column(name = "email")
	private String email;

	@Column(name = "contactno")
	private String contactno;

	@Column(name = "gender")
	private String gender;
	


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public Date getBdate() {
		return bdate;
	}

	public void setBdate(Date bdate) {
		this.bdate = bdate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


	public Students() {
		super();
	}

	public Students(String fname, String mname, String lname, String qualification, Date bdate, String email,
			String contactno, String gender) {
		super();
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.qualification = qualification;
		this.bdate = bdate;
		this.email = email;
		this.contactno = contactno;
		this.gender = gender;
	
	}

	public Students(long id, String fname, String mname, String lname, String qualification, Date bdate, String email,
			String contactno, String gender) {
		super();
		this.id = id;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.qualification = qualification;
		this.bdate = bdate;
		this.email = email;
		this.contactno = contactno;
		this.gender = gender;
	}
	
	
}

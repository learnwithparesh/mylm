package com.lms.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="topics")
public class Topics implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "tname")
	private String tname;
	
	@Column(name = "description")
	private String description;
	
	@JsonIgnore
	@OneToOne
    private Syllabus syllabus;

	
	@OneToMany(mappedBy = "topics", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JsonIgnoreProperties("topics")
    private Set<TopicsMainFile> topicsMainFile;
	
	
	@OneToMany(mappedBy = "topics", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JsonIgnoreProperties("topics")
    private Set<Subtopics> subtopics;
	
	
	public Set<Subtopics> getSubtopics() {
		return subtopics;
	}

	public void setSubtopics(Set<Subtopics> subtopics) {
		this.subtopics = subtopics;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Syllabus getSyllabus() {
		return syllabus;
	}

	public void setSyllabus(Syllabus syllabus) {
		this.syllabus = syllabus;
	}

	public Set<TopicsMainFile> getTopicsMainFile() {
		return topicsMainFile;
	}

	public void setTopicsMainFile(Set<TopicsMainFile> topicsMainFile) {
		this.topicsMainFile = topicsMainFile;
	}

	public Topics() {
		super();
	}

	public Topics(String tname, String description, Syllabus syllabus) {
		super();
		this.tname = tname;
		this.description = description;
		this.syllabus = syllabus;
	}

	public Topics(long id, String tname, String description, Syllabus syllabus) {
		super();
		this.id = id;
		this.tname = tname;
		this.description = description;
		this.syllabus = syllabus;
	}

	@Override
	public String toString() {
		return "Topics [id=" + id + ", tname=" + tname + ", description=" + description + ", syllabus=" + syllabus
				+ ", topicsMainFile=" + topicsMainFile + ", subtopics=" + subtopics + "]";
	}

	
	
	
}

package com.lms.model;

import java.io.File;
import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="syllabus")
public class Syllabus implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "description")
	private String description;
	
	@OneToOne
    private Branches branches;
	
	@OneToOne
    private Standards standards;
	
	@OneToOne
    private Subjects subjects;

	
	@OneToMany(mappedBy = "syllabus", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JsonIgnoreProperties("syllabus")
    private Set<SyllabusMainFile> syllabusMainFile;


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Branches getBranches() {
		return branches;
	}


	public void setBranches(Branches branches) {
		this.branches = branches;
	}


	public Standards getStandards() {
		return standards;
	}


	public void setStandards(Standards standards) {
		this.standards = standards;
	}


	public Subjects getSubjects() {
		return subjects;
	}


	public void setSubjects(Subjects subjects) {
		this.subjects = subjects;
	}


	public Set<SyllabusMainFile> getSyllabusMainFile() {
		return syllabusMainFile;
	}


	public void setSyllabusMainFile(Set<SyllabusMainFile> syllabusMainFile) {
		this.syllabusMainFile = syllabusMainFile;
	}


	public Syllabus() {
		super();
	}


	public Syllabus(String description, Branches branches, Standards standards, Subjects subjects,
			Set<SyllabusMainFile> syllabusMainFile) {
		super();
		this.description = description;
		this.branches = branches;
		this.standards = standards;
		this.subjects = subjects;
		this.syllabusMainFile = syllabusMainFile;
	}


	public Syllabus(long id, String description, Branches branches, Standards standards, Subjects subjects,
			Set<SyllabusMainFile> syllabusMainFile) {
		super();
		this.id = id;
		this.description = description;
		this.branches = branches;
		this.standards = standards;
		this.subjects = subjects;
		this.syllabusMainFile = syllabusMainFile;
	}


	

	public Syllabus(String description, Branches branches, Standards standards, Subjects subjects) {
		super();
		this.description = description;
		this.branches = branches;
		this.standards = standards;
		this.subjects = subjects;
	}


	@Override
	public String toString() {
		return "Syllabus [id=" + id + ", description=" + description + ", branches=" + branches + ", standards="
				+ standards + ", subjects=" + subjects + ", syllabusMainFile=" + syllabusMainFile + "]";
	}


	
	
	
	


	
	
}

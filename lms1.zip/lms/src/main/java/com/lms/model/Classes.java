package com.lms.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="classes")
public class Classes implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "cname")
	private String cname;
	
	@Column(name = "description")
	private String description;
	
	@OneToOne
    private Branches branches;
	
	@OneToOne
    private Standards standards;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Branches getBranches() {
		return branches;
	}

	public void setBranches(Branches branches) {
		this.branches = branches;
	}

	public Standards getStandards() {
		return standards;
	}

	public void setStandards(Standards standards) {
		this.standards = standards;
	}

	public Classes() {
		super();
	}

	public Classes(String cname, String description, Branches branches, Standards standards) {
		super();
		this.cname = cname;
		this.description = description;
		this.branches = branches;
		this.standards = standards;
	}

	public Classes(long id, String cname, String description, Branches branches, Standards standards) {
		super();
		this.id = id;
		this.cname = cname;
		this.description = description;
		this.branches = branches;
		this.standards = standards;
	}



}

package com.lms.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="subtopicsmfile")
public class SubTopicsMainFile implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "subtopics_id", nullable = false)
	private Subtopics subtopics;
	
	@Column(name = "fileurl")
	private String fileurl;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	



	public Subtopics getSubtopics() {
		return subtopics;
	}

	public void setSubtopics(Subtopics subtopics) {
		this.subtopics = subtopics;
	}

	public String getFileurl() {
		return fileurl;
	}

	public void setFileurl(String fileurl) {
		this.fileurl = fileurl;
	}

	public SubTopicsMainFile() {
		super();
	}

	public SubTopicsMainFile(Subtopics subtopics, String fileurl) {
		super();
		this.subtopics = subtopics;
		this.fileurl = fileurl;
	}

	public SubTopicsMainFile(long id, Subtopics subtopics, String fileurl) {
		super();
		this.id = id;
		this.subtopics = subtopics;
		this.fileurl = fileurl;
	}

	public SubTopicsMainFile(String fileurl) {
		super();
		this.fileurl = fileurl;
	}

	@Override
	public String toString() {
		return "SubTopicsMainFile [id=" + id + ", subtopics=" + subtopics + ", fileurl=" + fileurl + "]";
	}



}

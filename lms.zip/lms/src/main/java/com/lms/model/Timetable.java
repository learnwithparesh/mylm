package com.lms.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.jdbc.BatchedTooManyRowsAffectedException;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="timetable")
public class Timetable implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	
	@OneToOne
	private Classes classes;
	
	@OneToOne
	private Subjects subjects;
	
	@OneToOne
	private Teachers teachers;
	
	//@JsonFormat( pattern = "dd/MM/yyyy",timezone="IST")
	@Column(name = "starttime")
	private Date starttime;
	
	//@JsonFormat( pattern = "dd/MM/yyyy",timezone="IST")
	@Column(name = "endtime")
	private Date endtime;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Classes getClasses() {
		return classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public Subjects getSubjects() {
		return subjects;
	}

	public void setSubjects(Subjects subjects) {
		this.subjects = subjects;
	}

	public Teachers getTeachers() {
		return teachers;
	}

	public void setTeachers(Teachers teachers) {
		this.teachers = teachers;
	}

	public Date getStarttime() {
		return starttime;
	}

	public void setStarttime(Date starttime) {
		this.starttime = starttime;
	}

	public Date getEndtime() {
		return endtime;
	}

	public void setEndtime(Date endtime) {
		this.endtime = endtime;
	}

	public Timetable() {
		super();
	}

	public Timetable(Classes classes, Subjects subjects, Teachers teachers, Date starttime, Date endtime) {
		super();
		this.classes = classes;
		this.subjects = subjects;
		this.teachers = teachers;
		this.starttime = starttime;
		this.endtime = endtime;
	}

	public Timetable(long id, Classes classes, Subjects subjects, Teachers teachers, Date starttime, Date endtime) {
		super();
		this.id = id;
		this.classes = classes;
		this.subjects = subjects;
		this.teachers = teachers;
		this.starttime = starttime;
		this.endtime = endtime;
	}
	
	
	
	
}

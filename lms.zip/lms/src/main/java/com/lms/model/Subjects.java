package com.lms.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="subjects")
public class Subjects implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "sname")
	private String sname;
	
	
	@Column(name = "description")
	private String description;
	
	@OneToOne
    private Branches branches;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Branches getBranches() {
		return branches;
	}

	public void setBranches(Branches branches) {
		this.branches = branches;
	}

	public Subjects() {
		super();
	}

	public Subjects(String sname, String description, Branches branches) {
		super();
		this.sname = sname;
		this.description = description;
		this.branches = branches;
	}

	public Subjects(long id, String sname, String description, Branches branches) {
		super();
		this.id = id;
		this.sname = sname;
		this.description = description;
		this.branches = branches;
	}
	
	
		
}

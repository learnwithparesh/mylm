package com.lms.model;

import java.io.Serializable;

import org.springframework.web.multipart.MultipartFile;

public class Fileslist implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String filesname;


	private MultipartFile files;


	public String getFilesname() {
		return filesname;
	}


	public void setFilesname(String filesname) {
		this.filesname = filesname;
	}


	public MultipartFile getFiles() {
		return files;
	}


	public void setFiles(MultipartFile files) {
		this.files = files;
	}


	public Fileslist(MultipartFile files) {
		super();
		this.files = files;
	}


	public Fileslist() {
		super();
	}
	

}

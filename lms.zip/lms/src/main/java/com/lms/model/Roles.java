package com.lms.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="roles")
public class Roles implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="role_name")
	private String role_name;
	
	@Column(name="description")
	private String description;
	
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRole_name() {
		return role_name;
	}

	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Roles() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Roles(long id, String role_name, String description) {
		super();
		this.id = id;
		this.role_name = role_name;
		this.description = description;
	}

	public Roles(String role_name, String description) {
		super();
		this.role_name = role_name;
		this.description = description;
	}

	@Override
	public String toString() {
		return "Roles [id=" + id + ", role_name=" + role_name + ", description=" + description + "]";
	}
	
	

}

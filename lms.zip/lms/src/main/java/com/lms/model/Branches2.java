package com.lms.model;

import java.io.File;
import java.io.Serializable;

import org.springframework.web.multipart.MultipartFile;


public class Branches2 implements Serializable
{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private long id;
	
	
	private String bname;
	
	
	private String description;
	
	private File mfile;
	
	private String mfileUploadContentType ;
	private String mfileUploadFileName;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	

	
	public File getMfile() {
		return mfile;
	}

	public void setMfile(File mfile) {
		this.mfile = mfile;
	}

	public String getMfileUploadContentType() {
		return mfileUploadContentType;
	}

	public void setMfileUploadContentType(String mfileUploadContentType) {
		this.mfileUploadContentType = mfileUploadContentType;
	}

	public String getMfileUploadFileName() {
		return mfileUploadFileName;
	}

	public void setMfileUploadFileName(String mfileUploadFileName) {
		this.mfileUploadFileName = mfileUploadFileName;
	}

	
	public Branches2(String bname, String description, File mfile, String mfileUploadContentType,
			String mfileUploadFileName) {
		super();
		this.bname = bname;
		this.description = description;
		this.mfile = mfile;
		this.mfileUploadContentType = mfileUploadContentType;
		this.mfileUploadFileName = mfileUploadFileName;
	}

	public Branches2(String bname, String description, File mfile) {
		super();
		this.bname = bname;
		this.description = description;
		this.mfile = mfile;
	}

	public Branches2(long id, String bname, String description) {
		super();
		this.id = id;
		this.bname = bname;
		this.description = description;
	}

	public Branches2() {
		super();
	}

	public Branches2(String bname, String description) {
		super();
		this.bname = bname;
		this.description = description;
	}
	
	
}

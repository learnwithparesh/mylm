package com.lms.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lms.model.Boards;
import com.lms.model.Standards;

@Repository
public interface StandardsRepository  extends JpaRepository<Standards, Long>
{
	Optional<Standards> findById(Long id);
}

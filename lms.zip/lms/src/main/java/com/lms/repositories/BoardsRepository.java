package com.lms.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lms.model.Boards;

@Repository
public interface BoardsRepository  extends JpaRepository<Boards, Long>
{
	Optional<Boards> findById(Long id);
}

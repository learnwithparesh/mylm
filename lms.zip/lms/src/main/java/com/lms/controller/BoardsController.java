package com.lms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lms.exceptionhandler.ResourceNotFoundException;
import com.lms.model.Boards;
import com.lms.repositories.BoardsRepository;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class BoardsController
{
	@Autowired
	BoardsRepository boardsRepository;
	
	
    @GetMapping("/boards")
    public List<Boards> getAllboardss() {
        return boardsRepository.findAll();
    }

    @GetMapping("/boards/{id}")
    public ResponseEntity<Boards> getboardsById(@PathVariable(value = "id") Long boardsId)
        throws ResourceNotFoundException {
        Boards boards = boardsRepository.findById(boardsId)
          .orElseThrow(() -> new ResourceNotFoundException("boards not found for this id :: " + boardsId));
        return ResponseEntity.ok().body(boards);
    }
    
    @PostMapping("/boards")
    public Boards createboards(@RequestBody Boards boards) {
    //	System.out.println("in add data"+boards.getMfile().length());
    	//System.out.println("in add data"+boards.getMfile().getAbsolutePath());
    	//System.out.println("in add data"+boards.getMfileUploadFileName());
    	Boards bn = boardsRepository.save(boards);
    	System.out.println("in add data" + bn.getId());
    	return bn;
        
    }

    @PutMapping("/boards/{id}")
    public ResponseEntity<Boards> updateboards(@PathVariable(value = "id") Long boardsId,
         @Valid @RequestBody Boards boardsDetails) throws ResourceNotFoundException {
        Boards boards = boardsRepository.findById(boardsId)
        .orElseThrow(() -> new ResourceNotFoundException("boards not found for this id :: " + boardsId));

        boards.setSname(boardsDetails.getSname());
        boards.setDescription(boardsDetails.getDescription());
        
        final Boards updatedboards = boardsRepository.save(boards);
        return ResponseEntity.ok(updatedboards);
    }

    @DeleteMapping("/boards/{id}")
    public Map<String, Boolean> deleteboards(@PathVariable(value = "id") Long boardsId)
         throws ResourceNotFoundException {
        Boards boards = boardsRepository.findById(boardsId)
       .orElseThrow(() -> new ResourceNotFoundException("boards not found for this id :: " + boardsId));

        boardsRepository.delete(boards);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
	
	

}

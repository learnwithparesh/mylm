package com.lms.controller;

import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.lms.exceptionhandler.ResourceNotFoundException;
import com.lms.model.SubTopicsMainFile;
import com.lms.model.Subtopics;
import com.lms.repositories.SubtopicsRepository;
import com.lms.repositories.SyllabusRepository;
import com.lms.repositories.TopicsRepository;
import com.lms.service.FileStorage;



@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SubsubtopicsController
{
	@Autowired
	SyllabusRepository sylrepo;
	
	@Autowired
	TopicsRepository toptrepo;
	
	@Autowired
	SubtopicsRepository subtrepo;
	
	
    @GetMapping("/subtopics")
    public List<Subtopics> getAllSubtopicss() {
        return subtrepo.findAll();
    }

    @GetMapping("/subtopics/{id}")
    public ResponseEntity<Subtopics> getSubtopicsById(@PathVariable(value = "id") Long subtopicsId)
        throws ResourceNotFoundException {
        Subtopics subtopics = subtrepo.findById(subtopicsId)
          .orElseThrow(() -> new ResourceNotFoundException("Subtopics not found for this id :: " + subtopicsId));
        return ResponseEntity.ok().body(subtopics);
    }
    
	/*
	 * @GetMapping("/subtopicss/{id}") public List<Subtopics>
	 * getSubtopicsById1(@PathVariable(value = "id") Long subtopicsId) throws
	 * ResourceNotFoundException { List<Subtopics> subtopics =
	 * subtrepo.findBySyllabus(sylrepo.findById(subtopicsId).get()); return
	 * subtopics; }
	 */
    
	/*
	 * @PostMapping("/subtopics") public Subtopics createSubtopics(@ModelAttribute
	 * Subtopics subtopics) {
	 * 
	 * System.out.println("g");
	 * System.out.println("subtopics.get"+subtopics.getDescription());
	 * System.out.println("in add data"+subtopics.getMfile()[0].getAbsolutePath());
	 * for(int i=0; i< subtopics.getMfile().length;i++) {
	 * System.out.println("in add data"+subtopics.getMfile()[i].length());
	 * System.out.println("in add data"+subtopics.getMfile()[i].getAbsolutePath());
	 * // System.out.println("in add data"+subtopics.getMainfile()[i].
	 * getMfileUploadFileName());
	 * 
	 * }
	 * 
	 * Subtopics bn = subtrepo.save(subtopics);
	 * 
	 * //System.out.println("in add data" + bn.getId()); return bn;
	 * 
	 * }
	 */
    
    @Value("${serviceURL}")
	private String UPLOADED_FOLDER;
    private String databaseFolder ="/assets/uploadedfiles/";
    
    
    @Autowired
    FileStorage fileStorage;
    
    @PostMapping("/subtopics")
    public Subtopics uploadFileMulti(@RequestParam("stdescription") String stdescription,@RequestParam("stname") String stname,@RequestParam("tid") String tid,@RequestParam("imageFile") MultipartFile[] files) throws Exception {
    	  Subtopics rlist = new Subtopics();
          String directoryName;
		   String result = null;
		   Date today = new Date();
        try {
        	
    		System.out.println("dd"+stdescription);
    		System.out.println("sid"+tid);
    		System.out.println("tname"+stname);
    	//	System.out.println("subid"+subid);
          
         Subtopics mys = new Subtopics();
        		 
         mys.setDescription(stdescription);
         mys.setSubtname(stname);
         mys.setTopics(toptrepo.findById(Long.parseLong(tid)).get());
         
        // mys.setBoard(boardsrepo.getOne(Long.parseLong(boardid)));
         //mys.setDescription(description);
        		 
        		 
        String today1 = today.toString().replaceAll("[\\s+\\-\\+\\.\\^:,]","");
        	  directoryName = UPLOADED_FOLDER.concat(String.valueOf(today1));
        	  databaseFolder = databaseFolder.concat(String.valueOf(today1));

        	    File directory = new File(directoryName);
        	    if (! directory.exists()){
        	        directory.mkdir();
        	    }

 
        	List<String> fileNames = null;  
	    	Set<SubTopicsMainFile> smnewlist = new HashSet<SubTopicsMainFile>();
        //	SubtopicsMainFile smnew = new SubtopicsMainFile();
	    		
		        fileNames = Arrays.asList(files)
		                .stream()
		                .map(file -> {
		                	fileStorage.store1(file,directoryName);
		                	System.out.println("ff"+file.getOriginalFilename());
		                	System.out.println("ff"+directoryName);
		                	
		                	SubTopicsMainFile smnew = new SubTopicsMainFile(directoryName.concat("/").concat(file.getOriginalFilename()));
		                	smnew.setSubtopics(mys);
		                	smnewlist.add(smnew);
		                	
                    	     return file.getOriginalFilename();
		                })
		                .collect(Collectors.toList());
		       mys.setSubTopicsMainFile(smnewlist);
		       rlist = subtrepo.save(mys);	
        }
        // Here Catch IOException only.
        // Other Exceptions catch by RestGlobalExceptionHandler class.
        catch (Exception e) {
            e.printStackTrace();
            return rlist;
  //          return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        int v = 0;
 
      return rlist;
     //return new ResponseEntity<String>("Uploaded to: " + result, HttpStatus.OK);
    }

    @PutMapping("/subtopics/{id}")
    public ResponseEntity<Subtopics> updateSubtopics(@PathVariable(value = "id") Long subtopicsId,
         @Valid @RequestBody Subtopics subtopicsDetails) throws ResourceNotFoundException {
        Subtopics subtopics = subtrepo.findById(subtopicsId)
        .orElseThrow(() -> new ResourceNotFoundException("Subtopics not found for this id :: " + subtopicsId));

        
        subtopics.setDescription(subtopicsDetails.getDescription());
        
        final Subtopics updatedSubtopics = subtrepo.save(subtopics);
        return ResponseEntity.ok(updatedSubtopics);
    }

    @DeleteMapping("/subtopics/{id}")
    public Map<String, Boolean> deleteSubtopics(@PathVariable(value = "id") Long subtopicsId)
         throws ResourceNotFoundException {
        Subtopics subtopics = subtrepo.findById(subtopicsId)
       .orElseThrow(() -> new ResourceNotFoundException("Subtopics not found for this id :: " + subtopicsId));

        subtrepo.delete(subtopics);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
	
	

}
